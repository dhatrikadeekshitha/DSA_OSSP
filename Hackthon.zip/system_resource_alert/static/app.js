const $ = (id) => document.getElementById(id);
let toastTimer;

function showToast(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}

function setMetric(name, value, limit) {
  $(name + "Value").textContent = value;
  const bar = $(name + "Bar");
  if (bar) {
    bar.style.width = Math.max(0, Math.min(100, Number(value))) + "%";
    bar.style.background = Number(value) >= Number(limit) ? "#e76f72" : "";
  }
}

function formatUptime(seconds) {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  return days ? `${days}d ${hours}h up` : `${hours}h ${mins}m up`;
}

function renderProcesses(processes) {
  const tbody = $("processTable");
  if (!processes || !processes.length) {
    tbody.innerHTML = '<tr><td colspan="5" class="empty">No process information available.</td></tr>';
    return;
  }
  tbody.innerHTML = processes.map(p => {
    const name = escapeHtml(p.name);
    const status = escapeHtml(String(p.status).replaceAll("_", " "));
    return `<tr>
      <td><div class="proc-name"><span class="proc-icon">${name.slice(0,1).toUpperCase()}</span><span title="${name}">${name}</span></div></td>
      <td>${p.pid ?? "—"}</td>
      <td><span class="mini-meter"><i style="width:${Math.min(100, p.cpu)}%"></i></span>${p.cpu}%</td>
      <td>${p.memory}%</td><td><span class="status-tag">${status}</span></td>
    </tr>`;
  }).join("");
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

function renderAlerts(alerts) {
  $("alertBadge").textContent = alerts.length;
  const list = $("alertList");
  if (!alerts.length) {
    list.innerHTML = '<div class="empty">No alerts yet. The system is operating within configured thresholds.</div>';
    return;
  }
  list.innerHTML = alerts.slice(0, 12).map(a => `
    <div class="alert-item">
      <div class="alert-symbol">!</div>
      <div class="alert-content"><div class="alert-title">${escapeHtml(a.metric)} threshold exceeded</div>
      <div class="alert-desc">${escapeHtml(a.message)} · configured limit: ${escapeHtml(a.limit)}</div></div>
      <div class="alert-time">${escapeHtml(a.time)}</div>
    </div>`).join("");
}

async function refresh() {
  try {
    const response = await fetch("/api/metrics", {cache: "no-store"});
    const result = await response.json();
    if (!response.ok || !result.ok) throw new Error(result.error || "Metric collection failed");
    const m = result.metrics, t = result.thresholds;
    setMetric("cpu", m.cpu, t.cpu);
    setMetric("memory", m.memory, t.memory);
    setMetric("disk", m.disk, t.disk);
    $("processValue").textContent = m.process_count;
    $("cpuCores").textContent = `${m.cpu_cores} logical cores`;
    $("memoryDetail").textContent = `${m.memory_used_gb} / ${m.memory_total_gb} GB`;
    $("diskDetail").textContent = `${m.disk_used_gb} / ${m.disk_total_gb} GB`;
    $("uptime").textContent = formatUptime(m.uptime_seconds);
    $("updatedAt").textContent = m.updated_at;
    $("cpuLimitLabel").textContent = `${t.cpu}%`;
    $("memoryLimitLabel").textContent = `${t.memory}%`;
    $("diskLimitLabel").textContent = `${t.disk}%`;
    $("processLimitLabel").textContent = t.process_count;
    // Keep form inputs in sync unless the user is currently editing one.
    const active = document.activeElement;
    const map = {cpuLimit: t.cpu, memoryLimit: t.memory, diskLimit: t.disk, processLimit: t.process_count};
    Object.entries(map).forEach(([id, value]) => { if (active !== $(id)) $(id).value = value; });
    renderProcesses(m.processes);
    await refreshAlerts();
  } catch (err) {
    showToast("Could not read system metrics: " + err.message);
  }
}

async function refreshAlerts() {
  const response = await fetch("/api/alerts", {cache: "no-store"});
  if (response.ok) renderAlerts(await response.json());
}

$("thresholdForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = {
    cpu: Number($("cpuLimit").value),
    memory: Number($("memoryLimit").value),
    disk: Number($("diskLimit").value),
    process_count: Number($("processLimit").value)
  };
  try {
    const response = await fetch("/api/thresholds", {
      method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok || !result.ok) throw new Error(result.error || "Could not save thresholds");
    $("thresholdMessage").textContent = "Thresholds saved successfully.";
    showToast("Alert thresholds updated");
    refresh();
  } catch (err) {
    $("thresholdMessage").textContent = err.message;
    $("thresholdMessage").style.color = "#d15e62";
  }
});

$("clearAlerts").addEventListener("click", async () => {
  try {
    await fetch("/api/alerts/clear", {method: "POST"});
    await refreshAlerts();
    showToast("Alert history cleared");
  } catch (_) { showToast("Could not clear alert history"); }
});

refresh();
setInterval(refresh, 3000);
