# SysWatch — System Resource Alert and Notification System

A working local web dashboard that monitors CPU, memory, disk, and process usage. It compares measurements against configurable thresholds and displays alerts when a limit is reached.

## Features

- Live CPU, RAM, disk and process-count monitoring
- Top 20 processes sorted by CPU usage, including PID, memory, and status
- Configurable thresholds through the dashboard
- Recent alert history with timestamps
- Duplicate-alert cooldown (one alert per metric per minute)
- Responsive dashboard for desktop and mobile
- JSON API endpoints for metrics, alerts, and threshold settings
- Works on Windows, macOS, and Linux (disk metric uses the system drive on Windows and `/` on macOS/Linux)

## Requirements

- Python 3.10 or newer recommended
- Internet is not required for the backend. The dashboard uses a Google Fonts import for typography; if offline, it falls back to system fonts.
- Install dependencies from `requirements.txt`.

## Setup

### macOS / Linux

1. Extract the project ZIP and open Terminal in the `system_resource_alert` folder.
2. Create a virtual environment:

   ```bash
   python3 -m venv .venv
   ```

3. Activate it:

   ```bash
   source .venv/bin/activate
   ```

4. Install dependencies:

   ```bash
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

5. Start the server:

   ```bash
   python app.py
   ```

6. Open this address in your browser:

   **http://127.0.0.1:5000**

Keep the terminal open while using the dashboard. Press `Ctrl+C` to stop the server.

### Windows (PowerShell)

1. Extract the ZIP and open PowerShell in the `system_resource_alert` folder.
2. Create a virtual environment:

   ```powershell
   py -m venv .venv
   ```

3. Activate it:

   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, run this for the current terminal only, then activate again:

   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   .\.venv\Scripts\Activate.ps1
   ```

4. Install and run:

   ```powershell
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   python app.py
   ```

5. Open **http://127.0.0.1:5000** in a browser. Stop with `Ctrl+C`.

## Compilation

Python is interpreted, so there is no separate compilation step. To check that the source parses correctly:

```bash
python -m py_compile app.py
```

The command creates a `__pycache__` folder. It is safe to ignore.

## How it works

1. The browser requests `/api/metrics` every 3 seconds.
2. Flask uses `psutil` to read CPU percentage, virtual memory, disk usage, boot time, and process information.
3. The backend compares CPU, memory, disk and process count to the configured limits.
4. If a threshold is reached or exceeded, an alert is added to the in-memory alert history.
5. The web dashboard refreshes the cards, process table, and recent alerts.
6. The threshold form sends updates to `/api/thresholds`.

## Default thresholds

| Metric | Default |
|---|---:|
| CPU usage | 80% |
| Memory usage | 85% |
| Disk usage | 90% |
| Process count | 250 |

You can change these values on the dashboard. CPU, memory, and disk limits accept 1–100. Process count accepts 1–100000. Settings and alerts are stored in memory and reset when the server restarts.

## API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| `GET` | `/api/metrics` | Current metrics, top processes, and threshold settings |
| `GET` | `/api/alerts` | Recent alert history |
| `POST` | `/api/thresholds` | Update threshold settings using JSON |
| `POST` | `/api/alerts/clear` | Clear the in-memory alert history |

Example threshold request:

```bash
curl -X POST http://127.0.0.1:5000/api/thresholds \
  -H "Content-Type: application/json" \
  -d '{"cpu":70,"memory":80,"disk":90,"process_count":250}'
```

## Testing alerts

To test the alert UI safely, temporarily set one threshold low (for example, CPU to `1%`) using the dashboard. If the current metric reaches that threshold, an alert should appear. Restore the original threshold afterward. A low threshold does not force CPU usage; it only makes the trigger easier to reach.

## Project structure

```text
system_resource_alert/
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   └── index.html
└── static/
    ├── app.js
    └── style.css
```

## Important notes

- This is a local monitoring prototype, not an enterprise monitoring agent.
- The server binds to `127.0.0.1` so the dashboard is not exposed to other computers by default.
- Process names and resource values depend on the operating system and the permissions of the user running Python. Some process details may be inaccessible and are skipped.
- The process CPU readings can initially be `0` until `psutil` has enough sampling history.
- The alert history is session-only and is not persisted to disk.
- Do not expose this development server directly to the public internet. Add authentication, TLS, persistent storage, and production-grade serving before any wider deployment.
