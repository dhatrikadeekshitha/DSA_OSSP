from flask import Flask, render_template, jsonify, request
import psutil
import time
import threading
from collections import deque
from datetime import datetime

app = Flask(__name__)

# Editable default thresholds (percentages except process count).
thresholds = {
    "cpu": 80,
    "memory": 85,
    "disk": 90,
    "process_count": 250
}
alert_history = deque(maxlen=100)
last_alert_at = {}
ALERT_COOLDOWN_SECONDS = 60
history_lock = threading.Lock()


def add_alert(metric, value, limit, message):
    """Avoid filling the alert list with the same alert every polling cycle."""
    now = time.time()
    key = metric
    if now - last_alert_at.get(key, 0) < ALERT_COOLDOWN_SECONDS:
        return
    last_alert_at[key] = now
    with history_lock:
        alert_history.appendleft({
            "time": datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z"),
            "metric": metric,
            "value": round(value, 1) if isinstance(value, (int, float)) else value,
            "limit": limit,
            "message": message,
            "severity": "warning"
        })


def collect_metrics():
    cpu = psutil.cpu_percent(interval=0.15)
    memory = psutil.virtual_memory()
    disk = psutil.disk_usage(os_path_root())
    processes = []
    for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent", "status"]):
        try:
            info = proc.info
            processes.append({
                "pid": info.get("pid"),
                "name": info.get("name") or "Unknown",
                "cpu": round(info.get("cpu_percent") or 0, 1),
                "memory": round(info.get("memory_percent") or 0, 1),
                "status": info.get("status") or "unknown"
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue

    processes.sort(key=lambda item: item["cpu"], reverse=True)
    process_count = len(psutil.pids())

    values = {
        "cpu": round(cpu, 1),
        "memory": round(memory.percent, 1),
        "disk": round(disk.percent, 1),
        "process_count": process_count,
        "memory_used_gb": round((memory.total - memory.available) / (1024 ** 3), 2),
        "memory_total_gb": round(memory.total / (1024 ** 3), 2),
        "disk_used_gb": round(disk.used / (1024 ** 3), 2),
        "disk_total_gb": round(disk.total / (1024 ** 3), 2),
        "cpu_cores": psutil.cpu_count(logical=True) or 1,
        "uptime_seconds": max(0, int(time.time() - psutil.boot_time())),
        "processes": processes[:20],
        "updated_at": datetime.now().astimezone().strftime("%H:%M:%S")
    }

    if values["cpu"] >= thresholds["cpu"]:
        add_alert("CPU", values["cpu"], thresholds["cpu"], f"CPU usage is {values['cpu']}%")
    if values["memory"] >= thresholds["memory"]:
        add_alert("Memory", values["memory"], thresholds["memory"], f"Memory usage is {values['memory']}%")
    if values["disk"] >= thresholds["disk"]:
        add_alert("Disk", values["disk"], thresholds["disk"], f"Disk usage is {values['disk']}%")
    if process_count >= thresholds["process_count"]:
        add_alert("Processes", process_count, thresholds["process_count"],
                  f"Running process count is {process_count}")
    return values


def os_path_root():
    # On Windows, use the system drive; on macOS/Linux, use root.
    import os
    if os.name == "nt":
        return os.environ.get("SystemDrive", "C:") + "\\\\"
    return "/"


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/metrics")
def api_metrics():
    try:
        return jsonify({"ok": True, "metrics": collect_metrics(), "thresholds": thresholds})
    except Exception as exc:
        app.logger.exception("Unable to collect system metrics")
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route("/api/alerts")
def api_alerts():
    with history_lock:
        return jsonify(list(alert_history))


@app.route("/api/thresholds", methods=["POST"])
def api_thresholds():
    payload = request.get_json(silent=True) or {}
    limits = {
        "cpu": (1, 100),
        "memory": (1, 100),
        "disk": (1, 100),
        "process_count": (1, 100000)
    }
    updated = {}
    for key, (low, high) in limits.items():
        if key not in payload:
            continue
        try:
            value = int(payload[key])
        except (TypeError, ValueError):
            return jsonify({"ok": False, "error": f"{key} must be a whole number"}), 400
        if not low <= value <= high:
            return jsonify({"ok": False, "error": f"{key} must be between {low} and {high}"}), 400
        updated[key] = value
    if not updated:
        return jsonify({"ok": False, "error": "No valid threshold values provided"}), 400
    thresholds.update(updated)
    return jsonify({"ok": True, "thresholds": thresholds})


@app.route("/api/alerts/clear", methods=["POST"])
def clear_alerts():
    with history_lock:
        alert_history.clear()
    return jsonify({"ok": True})


if __name__ == "__main__":
    # Accessible only from this computer by default.
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
